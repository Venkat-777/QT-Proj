#include "Vector.h"
using namespace MC_Vec;

int main()
{
	//declaring vector using overloaded constructor
	Vector<int> vec(10);

	//storing values on vector using push_back
	for (int i = 1; i <= 10; i++)
	{
		vec.push_back(i);
	}

	//printing vector
	for (int i = 0; i < vec.size(); i++)
	{
		std::cout << vec[i] << " ";
	}

	std::cout << "\n";

	//invoking copy constructor to create a copy of vec
	Vector<int> copyVec(vec);

	//printing copied vector
	for (int i = 0; i < copyVec.size(); i++)
	{
		std::cout << copyVec[i] << " ";
	}

	std::cout << "\n";

	//invoking move operator to move copyVec vector into moveVec
	Vector<int> moveVec = std::move(copyVec);

	for (int i = 0; i < moveVec.size(); i++)
	{
		std::cout << moveVec[i] << " ";
	}

	std::cout << "\n";
}
